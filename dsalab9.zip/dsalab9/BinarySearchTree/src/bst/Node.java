package bst;

public class Node 
{
	int data;
	Node left=null;
	Node right=null;
	
	Node()
	{
		data=0;
		left=null;
		right=null;
	}
	
	Node (int x)
	{
		data=x;
		left=null;
		right=null;
	}
}
