class Node{
	public int data;
	public Node next;
	public Node prev;
	public Node(){
		data=0;
		next=null;
		prev=null;
	}
	public Node(int x){
		data=x;
		next=null;
		prev=null;
	}
	}
