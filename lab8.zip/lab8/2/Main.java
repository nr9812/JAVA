class Main{
	public static void main(String []args){
		SortedList s1=new SortedList();
		s1.insert(0);
		s1.insert(20);
		s1.insert(30);
		s1.insert(40);
		s1.print();
		System.out.println();
		s1.Sorted_List(25);
		s1.print();
		System.out.println();
		s1.Sorted_List(35);
		s1.print();
		System.out.println();
		s1.Sorted_List(15);
		s1.print();
		System.out.println();
		s1.Sorted_List(12);
		s1.print();
		System.out.println();
	}
}
